angular.module('demo', [])
.controller('HelloWorld', function($scope, $http) {
    $http.get('http://restp/api/laptop').
        then(function(response) {
            $scope.greating = response.data;
        });
});