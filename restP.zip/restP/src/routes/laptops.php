<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app = new \Slim\App;

// Get All Laptops
$app->get('/api/laptops', function(Request $request, Response $response){
    
    $sql = "SELECT * FROM laptops";

    try{
        //Get DB Object
        $db = new db();
        //Connect
        $db = $db->connect();

        $stmt = $db->query($sql);
        $laptops = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db = null;
        echo json_encode($laptops);

    } catch(PDOException $e){
        echo '{"error": {"text": '.$e->getMessage().'}';

    }

});
    // Get Single Laptop
$app->get('/api/laptop/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    
    $sql = "SELECT * FROM laptops WHERE id = $id";

    try{
        //Get DB Object
        $db = new db();
        //Connect
        $db = $db->connect();

        $stmt = $db->query($sql);
        $laptop = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db = null;
        echo json_encode($laptop);

    } catch(PDOException $e){
        echo '{"error": {"text": '.$e->getMessage().'}';

    }
});
   // Add Laptop
   $app->post('/api/laptop/add', function(Request $request, Response $response){
    $brand = $request->getParam('brand');
    $model = $request->getParam('model');
    $release_date = $request->getParam('release_date');
    
    $sql = "INSERT INTO laptops (brand,model,release_date) VALUES (:brand,:model,:release_date)";

    try{
        //Get DB Object
        $db = new db();
        //Connect
        $db = $db->connect();

        $stmt = $db->prepare($sql);

        $stmt->bindParam(':brand',$brand);
        $stmt->bindParam(':model',$model);
        $stmt->bindParam(':release_date',$release_date);

        $stmt->execute();

        echo '{"notice": {"text": "Laptops was Added"}';

    } catch(PDOException $e){
        echo '{"error": {"text": '.$e->getMessage().'}';

    }
});
   // Update Laptop
   $app->put('/api/laptop/update/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $brand = $request->getParam('brand');
    $model = $request->getParam('model');
    $release_date = $request->getParam('release_date');
    
    $sql = "UPDATE laptops SET
                brand = :brand,
                model = :model,
                release_date = :release_date
            WHERE id = $id";

    try{
        //Get DB Object
        $db = new db();
        //Connect
        $db = $db->connect();

        $stmt = $db->prepare($sql);

        $stmt->bindParam(':brand',$brand);
        $stmt->bindParam(':model',$model);
        $stmt->bindParam(':release_date',$release_date);

        $stmt->execute();

        echo '{"notice": {"text": "Laptops was Updated"}';

    } catch(PDOException $e){
        echo '{"error": {"text": '.$e->getMessage().'}';

    }
});
    // Delete Laptop
    $app->delete('/api/laptop/delete/{id}', function(Request $request, Response $response){
        $id = $request->getAttribute('id');
        
        $sql = "DELETE FROM laptops WHERE id = $id";
    
        try{
            //Get DB Object
            $db = new db();
            //Connect
            $db = $db->connect();
    
            $stmt = $db->prepare($sql);
            $stmt->execute();
            $db = null;
    
            echo '{"notice": {"text": "Laptops was Deleted"}';

        } catch(PDOException $e){
            echo '{"error": {"text": '.$e->getMessage().'}';
    
        }
    });
