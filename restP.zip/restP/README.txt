how to run this project


change localhost
1. go to D:\xampp\apache\conf\extra\httpd-vhosts.conf
2. add this code 
<VirtualHost *:80>
    DocumentRoot "D:xampp/htdocs"
    ServerName localhost
</VirtualHost>

<VirtualHost *:80>
    DocumentRoot "D:xampp/htdocs/restP/public"
    ServerName restP
</VirtualHost>
* the documentroot must be refer to your xampp directory.
3. don't forget to delete # front of 'NameVirtualHost *:80' in line 20

add host in apachee
1. open notepad and run as administrator
2. open file C:\Windows\System32\drivers\etc
3. click all file then you can see 'hosts' file
4. edit the 'hosts' file
5. add '127.0.0.1 restP' at the buttom code.
6. dont forget to Save.

restart your xampp

enter this link to know if it work http://restp/api/laptops

good luck!